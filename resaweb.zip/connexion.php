<?php
$db=new PDO ('mysql:host=localhost;dbname=michel_resaweb;port=3306;charset=utf8','michel_web','zjL0SwrWRHICj0caDQ');

// eviter de fermer balsie php quand c'ets une page avec que du php